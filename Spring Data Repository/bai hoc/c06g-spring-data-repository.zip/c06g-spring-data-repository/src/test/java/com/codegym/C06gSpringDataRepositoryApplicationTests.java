package com.codegym;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C06gSpringDataRepositoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
