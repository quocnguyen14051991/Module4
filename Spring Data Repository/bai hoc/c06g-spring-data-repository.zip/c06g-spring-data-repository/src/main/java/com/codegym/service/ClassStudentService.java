package com.codegym.service;

import com.codegym.entity.ClassStudent;

import java.util.List;

public interface ClassStudentService {

    List<ClassStudent> findAll();
}
