package com.codegym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C06gSpringWebserviceRestfulApplication {

    public static void main(String[] args) {
        SpringApplication.run(C06gSpringWebserviceRestfulApplication.class, args);
    }

}
