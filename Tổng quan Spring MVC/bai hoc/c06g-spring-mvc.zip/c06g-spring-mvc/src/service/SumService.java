package service;

public interface SumService {

    double sum2Num(double num1, double num2);
}
