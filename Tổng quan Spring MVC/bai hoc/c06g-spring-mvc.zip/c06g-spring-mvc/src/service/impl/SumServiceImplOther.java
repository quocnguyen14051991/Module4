package service.impl;

import org.springframework.stereotype.Service;
import service.SumService;

@Service
public class SumServiceImplOther implements SumService {
    @Override
    public double sum2Num(double num1, double num2) {
        return 0;
    }
}
